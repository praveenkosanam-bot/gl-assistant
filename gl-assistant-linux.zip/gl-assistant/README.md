# GL Assistant (Balances first) � PL/SQL + Robot

- All DB objects prefixed with **GLCAI_**
- Logic: PL/SQL only (no business logic outside DB)
- Tests: Robot Framework (DatabaseLibrary)
- VS Code + GitHub Copilot friendly layout

## How to run (quick)
1) Connect as owner schema in SQL*Plus/SQLcl:
   @scripts/run_all.sql

2) Run Robot tests:
   robot -d results robot/tests/balances.robot
